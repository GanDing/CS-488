#include "PickingExample.hpp"

int main( int argc, char **argv )
{
	CS488Window::launch(argc, argv, new PickingExample(), 1024, 768, "PickingExample" );
	return 0;
}
